<div id="large_modal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg" role="document" style="width:1000px;">
    <div id="large_modal_content" class="modal-content" style="border-radius:0;">

    </div>
  </div>
</div>
