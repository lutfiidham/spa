<div id="small_modal" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div id="small_modal_content" class="modal-content"  style="border-radius:0;">

    </div>
  </div>
</div>
