<span class="tooltip-text">
<table width="100%" border="0" cellspacing="0" cellpadding="4" class="table_total_item">
  <tr>
    <td align="center">Meja masih kosong</td>
    
  </tr>
</table>
<br />
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td ><a href="transaction.php?table_id=<?= $row['table_id']?>" style="text-decoration:none;"><div class="btn_edit_item">ADD ORDER</div></a></td>
   
  </tr>
</table>
</span>
