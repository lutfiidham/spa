  <table width="100%" border="0" cellspacing="0" cellpadding="0" class="test">
  <tr>
    <td width="76%">&nbsp;</td>
    <td width="50" align="right"><select id="change-page-size" class="page_new">
									<option value="10">10</option>
									<option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                </td>
                <td width="19%" align="right">
                <input id="filter" type="text" class="search_new" placeholder="Cari disini" size="30" /></td>
  </tr>
</table>